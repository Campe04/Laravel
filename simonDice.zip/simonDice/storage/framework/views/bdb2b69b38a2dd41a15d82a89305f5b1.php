<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Simon Dice</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
</head>

<body>
    <h1>Juega a Simon Dice</h1>

    <div id="instrucciones-simon-dice" style="font-family: Arial, sans-serif; max-width: 600px; margin: 20px auto; padding: 20px; border: 1px solid #ccc; border-radius: 8px; background-color: #f9f9f9;">
        <h2 style="text-align: center; color: #333;">Instrucciones de "Simón dice"</h2>
        <p><strong>Objetivo del juego:</strong></p>
        <p>Memoriza y repite la secuencia de números que Simón te muestra. A medida que avances, la secuencia será más larga y desafiante.</p>

        <p><strong>Cómo jugar:</strong></p>
        <ul>
            <li>El juego comienza con una secuencia de <strong>3 números</strong> que aparecerán uno tras otro.</li>
            <li>Memoriza la secuencia y luego ingrésala en el mismo orden.</li>
            <li>Si aciertas, pasarás al siguiente nivel y se añadirá <strong>un número más</strong> a la secuencia.</li>
        </ul>

        <p><strong>Cuándo pierdes:</strong></p>
        <p>Si ingresas los números en el orden incorrecto, el juego terminará. ¡Atento a cada número!</p>

        <p><strong>Consejo para ganar:</strong></p>
        <p>Intenta recordar la secuencia agrupando los números o creando patrones mentales que te ayuden a memorizarlos fácilmente.</p>

        <p><strong>Reto final:</strong></p>
        <p>¿Hasta qué nivel puedes llegar sin equivocarte? ¡Desafía tu memoria y supérate en cada partida!</p>
    </div>
    <br><br><br>
    <div style="text-align: center; margin-top: 20px;">
        <a href="<?php echo e(route('/jugar')); ?>" style="padding: 10px 20px; font-size: 16px; color: #fff; background-color: #007bff; text-decoration: none; border: none; border-radius: 5px; cursor: pointer; transition: background-color 0.3s;">
            JUGAR
        </a>
    </div>

</body>

</html><?php /**PATH /var/www/html/resources/views/simonDice.blade.php ENDPATH**/ ?>