<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/simonDice', function () {
    return view('simonDice');
})->name('presentacion');

Route::get('/jugar',function (){
    return view('jugar');
})->name('jugar-partida');