
<?php

namespace App\Http\Controllers;

use Nette\Utils\Random;

class SimonDice extends Controller{
    
    public function generarSecuencia($nivel=1){
        $secuencia = [];
        $num = new Random.random_int(0,9);
        for ($i=0; $i < $nivel+2; $i++) { 
            $secuencia[] = $num;
        }

        $data = ['secuencia' => $secuencia];
        $data = ['nivel'=> $nivel];
        return view('jugar',$data);
    }

    
}
