<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vista 1</title>
</head>
<body>
    <h1>Hola <?php echo e($nombre); ?> tiene <?php echo e(strlen($nombre)); ?> letras!</h1>
    <a href="<?php echo e(route('info')); ?>">Información acerca de Laravel</a>
</body>
</html><?php /**PATH /var/www/html/resources/views/hola.blade.php ENDPATH**/ ?>