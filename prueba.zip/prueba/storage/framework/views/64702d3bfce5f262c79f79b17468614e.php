<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vista 1</title>
</head>
<body>
    <h1>Hola mundo desde una vista !</h1>

</body>
</html><?php /**PATH /var/www/html/resources/views/hola2.blade.php ENDPATH**/ ?>