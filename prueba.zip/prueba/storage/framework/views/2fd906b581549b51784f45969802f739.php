<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alta realizada</title>
</head>
<body>
    <h1>Se ha realizado el alta con éxito</h1>
    <?php if($nombre=='Pepe'): ?>
        <h1>Hola PEPE</h1>
    <?php else: ?>
    <ul>
        <li>Nombre: <?php echo e($nombre); ?></li>
        <li>Apellidos: <?php echo e($apellidos); ?></li>
        <li>Teléfono: <?php echo e($telefono); ?></li>
    </ul>
    <?php endif; ?>
</body>
</html><?php /**PATH /var/www/html/resources/views/datos-alta.blade.php ENDPATH**/ ?>