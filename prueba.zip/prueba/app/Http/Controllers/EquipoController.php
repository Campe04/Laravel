<?php

namespace App\Http\Controllers;
use App\Models\Equipo;
use Illuminate\Http\Request;

class EquipoController extends Controller
{
    public function addEquipo(){
        $nuevo = new Equipo();
        
    }
}
